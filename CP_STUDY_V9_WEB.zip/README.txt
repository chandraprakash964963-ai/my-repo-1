CP STUDY V9 - WEB PACKAGE
=========================

This is a static website package ready to deploy to a static host (e.g. GitHub Pages).
It is NOT hosted yet, and does not include cloud accounts/synchronization.

Files:
- index.html: app
- manifest.webmanifest: installable web app metadata
- service-worker.js: cache/offline support
- icon-192.png, icon-512.png: app icons

Deploy with GitHub Pages (beginner steps):
1. Create a GitHub repository (e.g. cp-study).
2. Upload all files from this folder to the repository root (not the folder itself).
3. In the repository, open Settings -> Pages.
4. Choose "Deploy from a branch", select main and /(root), save.
5. Wait for GitHub Pages to show the public URL, then open that URL on your phone.
6. In Chrome on Android, menu -> Add to Home screen / Install app (if offered).

Notes:
- HTTPS hosting is required for service workers/PWA install.
- Your app data remains in the browser/device where you use it. This package does not sync between devices.
- Uploaded files and notes are stored locally in the browser; keep separate backups.
